#Arduino Threshold Library v1.0.2
Set and check numeric quantile scales.

* [Documentation](http://robotsbigdata.com/docs-arduino-threshold.html)
* [Download Library](https://github.com/alextaujenis/RBD_Threshold/raw/master/extras/RBD_Threshold.zip)
* [Project Website](http://robotsbigdata.com)
* [Report an Issue](https://github.com/alextaujenis/RBD_Threshold/issues/new)*

\**Please include your Arduino make/model and IDE version when reporting an issue with this library.*

#License
This code is available under the [MIT License](http://opensource.org/licenses/mit-license.php).